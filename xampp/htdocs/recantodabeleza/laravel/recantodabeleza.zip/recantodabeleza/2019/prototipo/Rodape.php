<div class="row">
	<div class="col-md-4" id="contato">
		<ul>
			<li>CONTATO</li>	
			<li>(31)98632-9996</li>
			<li>(31)99991-6135</li>	
		</ul>	
	</div>	

	<div class="col-md-4" id="ajuda">
		<p>AJUDA</p>
		<ul>
			<li><a href="">Como comprar</a></li>
			<li><a href="">Perguntas Frequentes</a></li>
			<li><a href="">Política de troca</a></li>
		</ul>
	</div>

	<div class="col-md-4" id="network">
		<div id="imagens"> 
			<a href="https://web.whatsapp.com"><img src="imagens/icwpp.png" alt="Imagem"/></a>
			<a href="https://www.instagram.com"><img src="imagens/icInsta.png" alt="Imagem"/></a>
			<a href="https://pt-br.facebook.com"><img src="imagens/icface.png" alt="Imagem"/></a>
		</div>
		<p id="email"> recantoBeleza@gmail.com </p>
	</div>		
</div>