
<div class="container-fluid">
	<div class="row">
		<div class="col-12" id="areaSuperior" >
			<a href="#"> Fale Conosco</a>
			<a href="#"> Quem somos? </a>
			<a href="#"> Ajuda </a>
		</div>
	</div>

	<div class="row">
		<div class="col-1">
			<a href="Home.php">
				<img src="imagens/logo.png" title="Recanto Beleza" alt="Recanto Beleza"/>
			</a>
		</div>

		<div class="col-1" id="titulo">
			<h1> <a href="Home.php"> RECANTO </br> BELEZA</a> </h1>
		</div>

		<!--<div class="col-sm-7">
			<div id="imaginary_container"> 
				<div class="input-group stylish-input-group">
					<input type="text" class="form-control"  placeholder="Buscar por..." style="height: 50px; margin-left: 10%;">
					<span class="input-group-addon">
						<button type="submit">
								<span> <i class="material-icons" style="font-size: 200%; margin-top: 30%; color: black;">search</i></span>
						</button>  
					</span>
				</div>
			</div>
		</div>-->
	</div>
</div>